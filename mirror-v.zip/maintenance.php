<?php
// coded by [ironsix] & PawN0
// The Next Level
// 
// Minggu, 12:07:57 24-11-2019
//

$judul = "Maintenance";
include 'thenextlevel/kepala.php';
include 'aset/heker.php';
?>

<center><img src="https://i.ibb.co/D56qppL/maintenance.png"></center>

<p>Maaf situs kami sedang dalam perbaikan.</p>


<style type="text/css">
	


h1{
  text-align: center;
  font-size: 100px;
  font-family: 'Acme', sans-serif;

}


p{
 
 text-align: center;
 font-size: 50px;
}


</style>



<?php
include 'aset/kaki.php';
?>
