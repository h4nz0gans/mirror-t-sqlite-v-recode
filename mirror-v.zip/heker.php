<!DOCTYPE html>
<html lang="en">
<head>
<title>h4nz0 Ganteng</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device=width, initial-scale=1">
</head>
<body>
<div align="center">
<h1>Heker nih pasti...</h1>
<font color="white">Dapat salam dari [h4nz0 Ganteng]</font>
</div>
</body>

</html>
