<!DOCTYPE html>

  <html>

<head>

<!-- Required meta tags -->
<meta charset="utf-8"> 
<meta name="viewport" content="width=device-width, initial-scale=0.75, shrink-to-fit=no"> 
 <meta name="Author" content="h4nz0"> 
<meta name="copyright" content="©2019">
<meta name="theme-color" content="#000">
 <meta name="description" content="_Don't touch me_">

<link rel="icon" href="https://upload.wikimedia.org/wikipedia/id/e/e8/Nasa-logo.jpg"> 

<link rel="shortcut icon" href="https://upload.wikimedia.org/wikipedia/id/e/e8/Nasa-logo.jpg"> 	

  

<!-- font Family -->

<link href="https://fonts.googleapis.com/css?family=IM+Fell+Great+Primer+SC&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css?family=Orbitron&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css?family=Inconsolata&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css?family=Source+Code+Pro&display=swap" rel="stylesheet">

<style type="text/css">

html {
padding: 0px;
}



h1 {
       font-size: 50px;
       color: red;  
       font-family: 'IM Fell Great Primer SC', serif;
       font-weight: bold;

}

h2 {
      
      font-family: 'Orbitron', sans-serif;
      font-size: 50px;


}

h3 {
       font-family: 'Inconsolata', monospace;
       font-size: 30px;
  


}


img[alt*="www.000webhost.com"]{
display:none
}

h4 {

      font-family: 'Source Code Pro', monospace;


}


</style>


    <title> <+ Owner_by h4nz0 |</title>

  </head>


<body>


<center><img src="https://i.ibb.co/SfP19b2/1579139041-picsay.png" height="400px" width="300px" /></center>

   <h1> Owner_h4nz0 </h1>






<br>



<h2>Apakah menghina dan menertawai kekurangan orang lain itu lucu?

Belum tentu diri kalian lebih baik,dari orang yang kalian tertawai itu...

</h2>



<br>

<h3> Gretz: <br>
           Rgs | Iron-six | Mr.peniswife | Mr.u.d.s.p | Ardel |             Azhar heker | Dimas07 | Z-mintiby

 </h3>


<hr >_____________________________________________________</hr>



  <iframe width="0px" height="0px" src="https://c.top4top.io/m_1476z4cfd0.mp3" allow="autoplay; encrypted-media" allowfullscreen></iframe>

</body>



<center><footer><h4> Copyright @2019_by_h4nz0 </h4> </footer></center>



</html>

