<?php
// coded by [ironsix] & PawN0
// The Next Level
// 
// Minggu, 12:07:57 24-11-2019
//

// :)
$db = new SQLite3('mirror_ccf-office.db');
?>
