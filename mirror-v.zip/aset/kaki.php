</div>
<br>
<div class="foot">
<span class="left"><b>&#169; <?php echo date("Y"); ?> mirror-c</b></span><span class="right"><font class="coded">Coded by [<font color="orange">ironsix</font>] & <font class="coded">Recode by <font color="orange">h4nz0</font></font><span>
    <br>
    <h4>Powered by Corazon Cyber Family</h4>

</div>
<div class="kelir"></div>
</body>
</html>
