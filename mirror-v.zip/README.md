# mirror-t lama versi sqlite
##### Source code situs mirroring defacer dengan PHP7 PDO, sqlite, PHP CURL


### Pemasangan
* Taruh di document root web atau dalam folder web
* Jalankan "install.php"
* Hapus "install.php"
* Done

* Default admin login akses "corazon/masokk.php", admin:1234abc

```
Dedicated to:
The Next Level
```
